# Firestore schema (Main App and Admin Panel must use these names)
| Collection | Doc ID | Key fields |
|---|---|---|
| users | tg_<telegramId> | uid, telegramId, role(admin/user), status(active/blocked), firstSeenAt, lastSeenAt |
| videos | auto | title, description, thumbnailUrl, category, tags[], cloudinaryPublicId, status(draft/published/unpublished), featured, order, viewCount, likeCount, commentCount, saveCount, unlockPolicy, createdAt, publishedAt |
| videoPrivate | = video id | playbackUrl, adConfig (admin/server only) |
| videoLikes | {videoId}_{uid} | uid, videoId, createdAt (ID makes duplicates impossible) |
| savedVideos | {uid}_{videoId} | uid, videoId, createdAt |
| comments | auto | uid, videoId, text, status(visible/hidden/deleted), createdAt, editedAt |
| unlockEntitlements | {uid}_{videoId}_{watch|save} | uid, videoId, scope, verification(verified|link_visit), grantedAt, expiresAt? |
| viewEvents | {videoId}_{uid}_{yyyymmdd} | videoId, uid, createdAt (one counted view per user/video/day) |
| adEvents | auto | uid, videoId, provider, type(attempt|click|verified), createdAt |
| products, posts, galleries, customPages | auto | status, order, content fields, publishedAt |
| menuItems | auto | label, icon, order, visible, enabled, contentType(shopping|posts|videos|images|link|page|mini_app), targetId |
| miniApps | auto | name, description, iconPublicId, url, category, order, status, parentId, openBehavior(telegram|web) |
| appConfig | public / draft / lastValid | validated theme, home layout, ad placement flags |
| reports, adminAuditLogs, rateLimits | auto | server-written; admin read (rateLimits: none) |
Cost notes: a Home load = 1 appConfig read + 1 menu query + one page of videos. Likes/saves/views are 1 write each plus a counter update.
Pagination: cursor on (status, publishedAt) with limit 20. Counters are updated by the server in the same transaction as the event doc.
