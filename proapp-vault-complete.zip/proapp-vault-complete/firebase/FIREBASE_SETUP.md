# Firebase setup (shared by Main App and Admin Panel — use ONE Firebase project)

## Deploy rules and indexes
    npm i -g firebase-tools
    firebase login
    # edit .firebaserc: replace YOUR_FIREBASE_PROJECT_ID (or: firebase use --add)
    firebase deploy --only firestore:rules,firestore:indexes
    # test locally first:  firebase emulators:start --only firestore

## Authentication
1. Console > Build > Authentication > Get started. No sign-in provider is needed: users sign in with
   custom tokens minted by the server after Telegram initData verification (uid = `tg_<telegramId>`).
2. Project settings > Service accounts > generate a key. Put its fields in Vercel env vars
   (FIREBASE_ADMIN_*). Never commit the key file.

## Initial admin
    npm i firebase-admin
    GOOGLE_APPLICATION_CREDENTIALS=/secure/path/key.json node scripts/set-admin.mjs <your_telegram_numeric_id>
Sets the `admin` custom claim and users/tg_<id>.role. Re-open the app to refresh the token.
Later role changes must be made through the admin API, which re-checks the caller's claim server-side.

## Storage
Firebase Storage is NOT used; Cloudinary holds all media. No storage.rules are provided on purpose.

## Security model
Clients have read-only access to published content and their own likes/saves/entitlements.
All writes use the Admin SDK from API routes. Unknown collections are denied by default.
