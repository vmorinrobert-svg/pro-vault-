import { NextResponse } from 'next/server';
import { getAuth } from 'firebase-admin/auth';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';
import { adminApp } from '@proapp/shared/server/admin';
import { verifyInitData, uidFor } from '@proapp/shared/telegram';

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const initData = body?.initData;
  if (typeof initData !== 'string' || initData.length > 4096) return NextResponse.json({ error: 'bad request' }, { status: 400 });
  try {
    const { user } = verifyInitData(initData, process.env.TELEGRAM_BOT_TOKEN!, Number(process.env.TELEGRAM_INITDATA_MAX_AGE_SECONDS ?? 3600));
    const uid = uidFor(user.id); const app = adminApp(); const ref = getFirestore(app).doc(`users/${uid}`);
    const snap = await ref.get();
    if (snap.data()?.status === 'blocked') return NextResponse.json({ error: 'blocked' }, { status: 403 });
    await ref.set({ uid, telegramId: String(user.id), firstName: user.first_name ?? null, username: user.username ?? null, status: snap.data()?.status ?? 'active',
      role: snap.data()?.role ?? 'user', lastSeenAt: FieldValue.serverTimestamp(), ...(snap.exists ? {} : { firstSeenAt: FieldValue.serverTimestamp() }) }, { merge: true });
    return NextResponse.json({ token: await getAuth(app).createCustomToken(uid) });
  } catch { return NextResponse.json({ error: 'unauthorized' }, { status: 401 }); }
}
