export default { transpilePackages: ['@proapp/shared'] };
