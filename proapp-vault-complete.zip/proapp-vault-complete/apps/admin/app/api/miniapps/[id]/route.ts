import { NextResponse } from 'next/server';
import { z } from 'zod';
import { getAdminCtx } from '@proapp/shared/server/guard';
import { miniAppsRepo, audit } from '@proapp/shared/server/miniAppsRepo';
import { updateMiniApp, setMiniAppStatus, deleteMiniApp } from '@proapp/shared/miniapps/service';
import { MiniAppBody, fail, hosts } from '../_lib';

type Ctx = { params: Promise<{ id: string }> };
export async function PATCH(req: Request, { params }: Ctx) {
  try {
    const admin = await getAdminCtx(req); const { id } = await params;
    const raw = await req.json().catch(() => null);
    const st = z.object({ status: z.enum(['draft', 'published', 'unpublished']) }).strict().safeParse(raw);
    if (st.success) { const item = await setMiniAppStatus(admin, miniAppsRepo, id, st.data.status); await audit(`miniapp.${st.data.status}`, admin.userId, id); return NextResponse.json({ item }); }
    const b = MiniAppBody.partial().required({ url: true, openBehavior: true }).safeParse(raw);
    if (!b.success) return NextResponse.json({ error: 'bad request' }, { status: 400 });
    const item = await updateMiniApp(admin, miniAppsRepo, id, b.data, hosts());
    await audit('miniapp.update', admin.userId, id);
    return NextResponse.json({ item });
  } catch (e) { return fail(e); }
}
export async function DELETE(req: Request, { params }: Ctx) {
  try { const admin = await getAdminCtx(req); const { id } = await params; await deleteMiniApp(admin, miniAppsRepo, id); await audit('miniapp.delete', admin.userId, id); return NextResponse.json({ ok: true }); }
  catch (e) { return fail(e); }
}
