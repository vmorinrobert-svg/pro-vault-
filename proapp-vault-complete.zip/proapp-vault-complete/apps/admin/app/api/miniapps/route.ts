import { NextResponse } from 'next/server';
import { getAdminCtx } from '@proapp/shared/server/guard';
import { miniAppsRepo, audit } from '@proapp/shared/server/miniAppsRepo';
import { createMiniApp } from '@proapp/shared/miniapps/service';
import { MiniAppBody, fail, hosts } from './_lib';

export async function GET(req: Request) {
  try { await getAdminCtx(req); } catch (e) { return fail(e); }
  const parentId = new URL(req.url).searchParams.get('parentId') ?? '';
  return NextResponse.json({ items: (await miniAppsRepo.listByParent(parentId)).sort((a, b) => a.order - b.order) });
}
export async function POST(req: Request) {
  try {
    const ctx = await getAdminCtx(req);
    const b = MiniAppBody.safeParse(await req.json().catch(() => null));
    if (!b.success) return NextResponse.json({ error: 'bad request' }, { status: 400 });
    const item = await createMiniApp(ctx, miniAppsRepo, b.data, hosts());
    await audit('miniapp.create', ctx.userId, item.id);
    return NextResponse.json({ item }, { status: 201 });
  } catch (e) { return fail(e); }
}
