import { NextResponse } from 'next/server';
import { z } from 'zod';
import { ForbiddenError, ValidationError } from '@proapp/shared/miniapps/service';

// Shared helpers live here, NOT in route.ts: Next.js route files may only export HTTP handlers and route config fields.
export const hosts = () => (process.env.APPROVED_HTTPS_HOSTS ?? '').split(',').map((h) => h.trim()).filter(Boolean);
export const MiniAppBody = z.object({
  name: z.string().min(1).max(60), description: z.string().max(300).default(''), iconPublicId: z.string().max(200).optional(),
  url: z.string().max(2048), category: z.string().max(40).optional(), order: z.number().int().min(0).default(0),
  status: z.enum(['draft', 'published', 'unpublished']).default('draft'), parentId: z.string().min(1).max(100), openBehavior: z.enum(['telegram', 'web']),
});
export function fail(e: unknown) {
  const s = e instanceof ValidationError ? 422 : e instanceof ForbiddenError ? 403 : 401;
  return NextResponse.json({ error: s === 422 ? (e as Error).message : s === 403 ? 'forbidden' : 'unauthorized' }, { status: s });
}
