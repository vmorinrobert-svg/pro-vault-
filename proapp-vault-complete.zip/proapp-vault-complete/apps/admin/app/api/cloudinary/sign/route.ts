import { NextResponse } from 'next/server';
import { getAuth } from 'firebase-admin/auth';
import { z } from 'zod';
import { adminApp } from '@proapp/shared/server/admin';
import { requireAdmin } from '@proapp/shared/authz';
import { buildUploadSignature, validateUpload } from '@proapp/shared/cloudinary';

const Body = z.object({ kind: z.enum(['video', 'image']), mime: z.string().max(100), size: z.number().int().positive() });
export async function POST(req: Request) {
  try {
    const idToken = (req.headers.get('authorization') ?? '').replace(/^Bearer /, '');
    requireAdmin(await getAuth(adminApp()).verifyIdToken(idToken, true)); // claim checked server-side on every call
  } catch { return NextResponse.json({ error: 'forbidden' }, { status: 403 }); }
  const b = Body.safeParse(await req.json().catch(() => null));
  if (!b.success) return NextResponse.json({ error: 'bad request' }, { status: 400 });
  const err = validateUpload(b.data.kind, b.data.mime, b.data.size);
  if (err) return NextResponse.json({ error: err }, { status: 422 });
  return NextResponse.json(buildUploadSignature(b.data.kind, { apiKey: process.env.CLOUDINARY_API_KEY!, apiSecret: process.env.CLOUDINARY_API_SECRET!, cloudName: process.env.NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME! }));
}
