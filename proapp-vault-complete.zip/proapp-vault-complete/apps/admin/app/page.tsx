export default function Page() { return <main>ProApp Vault Admin</main>; }
