export default function RootLayout({ children }: { children: React.ReactNode }) { return <html lang="en"><body style={{ background: '#0b0613', color: '#eee' }}>{children}</body></html>; }
