export type MiniAppLink =
  | { ok: true; kind: 'telegram' | 'web'; url: string }
  | { ok: false; reason: string };

const TG_HOSTS = new Set(['t.me', 'telegram.me']);
const BOT = /^[A-Za-z][A-Za-z0-9_]{4,31}$/;
const APP = /^[A-Za-z0-9_]{1,64}$/;
const fail = (reason: string): MiniAppLink => ({ ok: false, reason });

/** Accepts only https t.me Mini App links or https URLs on an approved host allowlist. */
export function validateMiniAppUrl(raw: string, opts: { approvedHosts?: string[] } = {}): MiniAppLink {
  const input = (raw ?? '').trim();
  if (!input || input.length > 2048) return fail('URL is empty or too long');
  let u: URL;
  try { u = new URL(input); } catch { return fail('Not a valid URL'); }
  if (u.protocol !== 'https:') return fail('Only https links are allowed');
  if (u.username || u.password) return fail('Credentials in URLs are not allowed');
  const host = u.hostname.toLowerCase();
  if (TG_HOSTS.has(host)) {
    const [bot, app, ...rest] = u.pathname.split('/').filter(Boolean);
    if (!bot || !BOT.test(bot) || rest.length) return fail('Invalid Telegram link');
    if (app && !APP.test(app)) return fail('Invalid Mini App short name');
    if (!app && !u.searchParams.has('startapp')) return fail('Link is a bot chat, not a Mini App');
    return { ok: true, kind: 'telegram', url: u.toString() };
  }
  const approved = (opts.approvedHosts ?? []).map((h) => h.toLowerCase());
  if (!approved.some((h) => host === h || host.endsWith('.' + h))) return fail('Host is not on the approved list');
  return { ok: true, kind: 'web', url: u.toString() };
}
