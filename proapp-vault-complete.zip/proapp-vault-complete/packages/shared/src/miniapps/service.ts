import { validateMiniAppUrl } from './url.ts';
import type { OpenBehavior } from './open.ts';

export type Role = 'admin' | 'user';
/** Built server-side from verified Telegram initData + Firestore role. Never from the browser. */
export interface Ctx { userId: string; role: Role; blocked?: boolean }
export type Status = 'draft' | 'published' | 'unpublished';
export interface MiniApp {
  id: string; name: string; description: string; iconPublicId?: string; url: string;
  category?: string; order: number; status: Status; parentId: string; openBehavior: OpenBehavior;
}
export type MiniAppInput = Omit<MiniApp, 'id'>;
export interface Repo {
  insert(a: MiniAppInput): Promise<MiniApp>;
  patch(id: string, p: Partial<MiniAppInput>): Promise<MiniApp>;
  remove(id: string): Promise<void>;
  listByParent(parentId: string): Promise<MiniApp[]>;
}
export class ForbiddenError extends Error {}
export class ValidationError extends Error {}

const assertAdmin = (c: Ctx) => { if (c.role !== 'admin' || c.blocked) throw new ForbiddenError('Admin only'); };
function checkUrl(url: string, behavior: OpenBehavior, hosts: string[]) {
  const l = validateMiniAppUrl(url, { approvedHosts: hosts });
  if (!l.ok) throw new ValidationError(l.reason);
  if (l.kind !== behavior) throw new ValidationError('Open behavior does not match link type');
}

export async function createMiniApp(c: Ctx, r: Repo, i: MiniAppInput, hosts: string[]) {
  assertAdmin(c); checkUrl(i.url, i.openBehavior, hosts); return r.insert(i);
}
export async function updateMiniApp(c: Ctx, r: Repo, id: string, p: Partial<MiniAppInput> & { url: string; openBehavior: OpenBehavior }, hosts: string[]) {
  assertAdmin(c); checkUrl(p.url, p.openBehavior, hosts); return r.patch(id, p);
}
export async function setMiniAppStatus(c: Ctx, r: Repo, id: string, status: Status) { assertAdmin(c); return r.patch(id, { status }); }
export async function deleteMiniApp(c: Ctx, r: Repo, id: string) { assertAdmin(c); return r.remove(id); }
/** Public listing: only published entries of one parent, ordered. */
export async function listPublished(r: Repo, parentId: string) {
  return (await r.listByParent(parentId)).filter((a) => a.status === 'published').sort((a, b) => a.order - b.order);
}
