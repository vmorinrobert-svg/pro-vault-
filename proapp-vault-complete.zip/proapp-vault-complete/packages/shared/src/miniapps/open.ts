import { validateMiniAppUrl } from './url.ts';

export type OpenBehavior = 'telegram' | 'web';
export type OpenResult = 'opened-telegram' | 'opened-web' | 'fallback';
/** Subset of window.Telegram.WebApp (official: openTelegramLink for t.me links, openLink for web). */
export interface WebAppLike {
  openTelegramLink?: (url: string) => void;
  openLink?: (url: string, options?: { try_instant_view?: boolean }) => void;
}

/** 'fallback' means nothing was opened: the UI must show a toast and offer a copy-link button. */
export function openMiniApp(
  entry: { url: string; openBehavior: OpenBehavior },
  webApp: WebAppLike | undefined,
  approvedHosts: string[] = [],
): OpenResult {
  const link = validateMiniAppUrl(entry.url, { approvedHosts });
  if (!link.ok || link.kind !== entry.openBehavior) return 'fallback';
  try {
    if (link.kind === 'telegram' && webApp?.openTelegramLink) { webApp.openTelegramLink(link.url); return 'opened-telegram'; }
    if (link.kind === 'web' && webApp?.openLink) { webApp.openLink(link.url); return 'opened-web'; }
  } catch { /* fall through */ }
  return 'fallback';
}
