import { getAuth } from 'firebase-admin/auth';
import { adminApp } from './admin';
import { requireAdmin } from '../authz.ts';
import type { Ctx } from '../miniapps/service.ts';
/** Verifies the Firebase ID token (revocation checked) and the admin claim. Role is never read from the request body. */
export async function getAdminCtx(req: Request): Promise<Ctx> {
  const token = (req.headers.get('authorization') ?? '').replace(/^Bearer /, '');
  const claims = await getAuth(adminApp()).verifyIdToken(token, true);
  requireAdmin(claims);
  return { userId: claims.uid, role: 'admin' };
}
