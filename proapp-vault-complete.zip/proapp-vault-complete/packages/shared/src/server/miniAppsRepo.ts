import { getFirestore, FieldValue } from 'firebase-admin/firestore';
import { adminApp } from './admin';
import type { Repo, MiniApp } from '../miniapps/service.ts';
const col = () => getFirestore(adminApp()).collection('miniApps');
const toApp = (d: FirebaseFirestore.DocumentSnapshot) => ({ id: d.id, ...(d.data() as Omit<MiniApp, 'id'>) }) as MiniApp;
export const miniAppsRepo: Repo = {
  async insert(a) { const r = await col().add({ ...a, createdAt: FieldValue.serverTimestamp() }); return toApp(await r.get()); },
  async patch(id, p) { await col().doc(id).update({ ...p, updatedAt: FieldValue.serverTimestamp() }); return toApp(await col().doc(id).get()); },
  async remove(id) { await col().doc(id).delete(); },
  async listByParent(parentId) { return (await col().where('parentId', '==', parentId).get()).docs.map(toApp); },
};
export async function audit(action: string, actorUid: string, target: string) {
  await getFirestore(adminApp()).collection('adminAuditLogs').add({ action, actorUid, target, createdAt: FieldValue.serverTimestamp() });
}
