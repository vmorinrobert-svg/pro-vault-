import { getApps, initializeApp, cert } from 'firebase-admin/app';
export function adminApp() {
  if (getApps().length) return getApps()[0];
  return initializeApp({ credential: cert({ projectId: process.env.FIREBASE_ADMIN_PROJECT_ID!, clientEmail: process.env.FIREBASE_ADMIN_CLIENT_EMAIL!, privateKey: process.env.FIREBASE_ADMIN_PRIVATE_KEY!.replace(/\\n/g, '\n') }) });
}
