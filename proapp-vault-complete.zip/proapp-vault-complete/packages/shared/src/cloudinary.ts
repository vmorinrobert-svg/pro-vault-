import { createHash } from 'node:crypto';
const EXCLUDED = new Set(['file', 'cloud_name', 'resource_type', 'api_key']);
/** Cloudinary signature: SHA1(sorted "k=v" joined by & + api_secret). */
export function signParams(params: Record<string, string | number>, secret: string) {
  const s = Object.keys(params).filter((k) => !EXCLUDED.has(k) && params[k] !== '').sort().map((k) => `${k}=${params[k]}`).join('&');
  return createHash('sha1').update(s + secret).digest('hex');
}
export type Kind = 'video' | 'image';
const RULES: Record<Kind, { max: number; types: string[] }> = {
  video: { max: 2_000_000_000, types: ['video/mp4', 'video/quicktime', 'video/webm'] },
  image: { max: 10_000_000, types: ['image/jpeg', 'image/png', 'image/webp'] },
};
export function validateUpload(kind: Kind, mime: string, size: number): string | null {
  const r = RULES[kind]; if (!r) return 'Unknown kind';
  if (!r.types.includes(mime)) return 'File type not allowed';
  if (!Number.isFinite(size) || size <= 0 || size > r.max) return 'File size not allowed';
  return null;
}
export function buildUploadSignature(kind: Kind, a: { apiKey: string; apiSecret: string; cloudName: string }, nowSec = Math.floor(Date.now() / 1000)) {
  const params = { folder: `proapp/${kind}s`, timestamp: nowSec };
  return { ...params, signature: signParams(params, a.apiSecret), apiKey: a.apiKey, cloudName: a.cloudName, resourceType: kind };
}
