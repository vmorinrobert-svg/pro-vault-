import { createHmac, timingSafeEqual } from 'node:crypto';
export interface TgUser { id: number; first_name?: string; last_name?: string; username?: string }
export class AuthError extends Error {}
/** Official Telegram Web Apps validation: HMAC-SHA256(secret=HMAC("WebAppData", botToken), data_check_string). */
export function verifyInitData(initData: string, botToken: string, maxAgeSec = 3600, nowSec = Math.floor(Date.now() / 1000)) {
  const p = new URLSearchParams(initData);
  const hash = p.get('hash');
  if (!hash || !/^[0-9a-f]{64}$/.test(hash)) throw new AuthError('missing hash');
  p.delete('hash');
  const dcs = [...p.entries()].sort(([a], [b]) => (a < b ? -1 : 1)).map(([k, v]) => `${k}=${v}`).join('\n');
  const secret = createHmac('sha256', 'WebAppData').update(botToken).digest();
  const calc = createHmac('sha256', secret).update(dcs).digest();
  if (!timingSafeEqual(calc, Buffer.from(hash, 'hex'))) throw new AuthError('bad signature');
  const authDate = Number(p.get('auth_date'));
  if (!Number.isFinite(authDate) || nowSec - authDate > maxAgeSec || authDate - nowSec > 60) throw new AuthError('expired');
  let user: TgUser;
  try { user = JSON.parse(p.get('user') ?? ''); } catch { throw new AuthError('no user'); }
  if (!Number.isSafeInteger(user?.id)) throw new AuthError('no user id');
  return { user, authDate };
}
export const uidFor = (telegramId: number) => `tg_${telegramId}`;
