import { validateMiniAppUrl } from './miniapps/url.ts';
export const APPROVED_ICONS = ['home', 'shopping-bag', 'newspaper', 'film', 'image', 'link', 'file-text', 'grid', 'gamepad', 'wrench', 'tag', 'star'] as const;
export const CONTENT_TYPES = ['shopping', 'posts', 'videos', 'images', 'link', 'page', 'mini_app'] as const;
export interface MenuInput { label: string; icon: string; order: number; visible: boolean; enabled: boolean; contentType: string; targetId?: string; color?: string; url?: string }
export function validateMenuItem(i: MenuInput, approvedHosts: string[] = []): string[] {
  const e: string[] = [];
  if (!i.label || i.label.length > 40 || /[<>]/.test(i.label)) e.push('label');
  if (!(APPROVED_ICONS as readonly string[]).includes(i.icon)) e.push('icon');
  if (!(CONTENT_TYPES as readonly string[]).includes(i.contentType)) e.push('contentType');
  if (!Number.isInteger(i.order) || i.order < 0) e.push('order');
  if (i.color && !/^#[0-9a-fA-F]{6}$/.test(i.color)) e.push('color');
  if (i.contentType === 'link') { if (!validateMiniAppUrl(i.url ?? '', { approvedHosts }).ok) e.push('url'); }
  else if (!i.targetId) e.push('targetId');
  return e;
}
