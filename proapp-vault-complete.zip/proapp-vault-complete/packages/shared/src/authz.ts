export class Forbidden extends Error {}
/** `claims` must come from a server-verified Firebase ID token, never from the request body. */
export function requireAdmin(claims: { admin?: unknown } | null | undefined) { if (claims?.admin !== true) throw new Forbidden('Admin only'); }
