import { createHmac, timingSafeEqual } from 'node:crypto';
export type Scope = 'watch' | 'save';
export type Verification = 'verified' | 'link_visit';
export class InvalidCompletion extends Error {}
export const entitlementId = (uid: string, videoId: string, scope: Scope) => `${uid}_${videoId}_${scope}`;
export interface Proof { raw: string; sig: string }
/** A provider completion event is trusted only if its HMAC over the raw JSON matches and it is fresh. */
function verifyEvent(p: Proof, secret: string, maxAgeSec: number, nowSec: number) {
  if (!/^[0-9a-f]{64}$/.test(p.sig)) return null;
  const calc = createHmac('sha256', secret).update(p.raw).digest();
  if (!timingSafeEqual(calc, Buffer.from(p.sig, 'hex'))) return null;
  try { const e = JSON.parse(p.raw); return nowSec - e.ts <= maxAgeSec && e.ts - nowSec <= 60 ? e : null; } catch { return null; }
}
export function buildEntitlement(a: { uid: string; videoId: string; scope: Scope; proof?: Proof; providerSecret?: string; allowLinkVisit: boolean; nowSec?: number; maxAgeSec?: number }) {
  const now = a.nowSec ?? Math.floor(Date.now() / 1000);
  let verification: Verification;
  if (a.proof) {
    const e = a.providerSecret ? verifyEvent(a.proof, a.providerSecret, a.maxAgeSec ?? 600, now) : null;
    if (!e || e.uid !== a.uid || e.videoId !== a.videoId || e.scope !== a.scope) throw new InvalidCompletion('Completion could not be verified');
    verification = 'verified';
  } else if (a.allowLinkVisit) verification = 'link_visit'; // a redirect/click is NOT a completed ad
  else throw new InvalidCompletion('Verified completion required');
  return { id: entitlementId(a.uid, a.videoId, a.scope), uid: a.uid, videoId: a.videoId, scope: a.scope, verification, grantedAt: now };
}
export const countsAsVerifiedReward = (e: { verification: Verification }) => e.verification === 'verified';
/** One counted view per user/video/UTC day via doc ID. Clicks never count. Limitation: multiple accounts. */
export const viewEventId = (videoId: string, uid: string, d = new Date()) => `${videoId}_${uid}_${d.toISOString().slice(0, 10).replace(/-/g, '')}`;
