import test from 'node:test';
import assert from 'node:assert/strict';
import { createHmac } from 'node:crypto';
import { verifyInitData } from '../src/telegram.ts';
import { signParams, validateUpload, buildUploadSignature } from '../src/cloudinary.ts';
import { buildEntitlement, countsAsVerifiedReward, InvalidCompletion, viewEventId } from '../src/unlock.ts';
import { validateMenuItem } from '../src/menu.ts';
import { requireAdmin } from '../src/authz.ts';

const TOKEN = '123:TEST'; const NOW = 1_800_000_000;
function initData(over: Record<string, string> = {}, tamper = false) {
  const f: Record<string, string> = { auth_date: String(NOW - 10), query_id: 'q', user: JSON.stringify({ id: 42, first_name: 'A' }), ...over };
  const dcs = Object.keys(f).sort().map((k) => `${k}=${f[k]}`).join('\n');
  const hash = createHmac('sha256', createHmac('sha256', 'WebAppData').update(TOKEN).digest()).update(dcs).digest('hex');
  return new URLSearchParams({ ...f, ...(tamper ? { query_id: 'x' } : {}), hash }).toString();
}
test('initData', () => {
  assert.equal(verifyInitData(initData(), TOKEN, 3600, NOW).user.id, 42);
  assert.throws(() => verifyInitData(initData({}, true), TOKEN, 3600, NOW));
  assert.throws(() => verifyInitData(initData(), 'other', 3600, NOW));
  assert.throws(() => verifyInitData(initData({ auth_date: String(NOW - 99999) }), TOKEN, 3600, NOW));
  assert.throws(() => verifyInitData('user=%7B%7D', TOKEN));
});
test('cloudinary signing (documented example vector) and validation', () => {
  assert.equal(signParams({ eager: 'w_400,h_300,c_pad|w_260,h_200,c_crop', public_id: 'sample_image', timestamp: 1315060510 }, 'abcd'), 'bfd09f95f331f558cbd1320e67aa8d488770583e');
  assert.equal(validateUpload('video', 'video/mp4', 1000), null);
  assert.ok(validateUpload('video', 'text/html', 1000)); assert.ok(validateUpload('image', 'image/png', 99e6));
  assert.equal(buildUploadSignature('image', { apiKey: 'k', apiSecret: 's', cloudName: 'c' }, 5).signature, signParams({ folder: 'proapp/images', timestamp: 5 }, 's'));
});
test('unlock: generic link is never a verified reward; bad proofs rejected', () => {
  const base = { uid: 'tg_1', videoId: 'v', scope: 'watch' as const, nowSec: NOW };
  const link = buildEntitlement({ ...base, allowLinkVisit: true });
  assert.equal(link.verification, 'link_visit'); assert.equal(countsAsVerifiedReward(link), false);
  assert.throws(() => buildEntitlement({ ...base, allowLinkVisit: false }), InvalidCompletion);
  const raw = JSON.stringify({ uid: 'tg_1', videoId: 'v', scope: 'watch', ts: NOW });
  const sig = createHmac('sha256', 'sec').update(raw).digest('hex');
  assert.equal(buildEntitlement({ ...base, allowLinkVisit: false, proof: { raw, sig }, providerSecret: 'sec' }).verification, 'verified');
  assert.throws(() => buildEntitlement({ ...base, allowLinkVisit: true, proof: { raw, sig: '0'.repeat(64) }, providerSecret: 'sec' }), InvalidCompletion);
  assert.throws(() => buildEntitlement({ ...base, uid: 'tg_2', allowLinkVisit: true, proof: { raw, sig }, providerSecret: 'sec' }), InvalidCompletion);
  assert.equal(buildEntitlement({ ...base, allowLinkVisit: true }).id, link.id);
});
test('view ids dedupe per user/video/day', () => {
  assert.equal(viewEventId('v', 'u', new Date('2026-10-26T01:00:00Z')), viewEventId('v', 'u', new Date('2026-10-26T23:00:00Z')));
  assert.notEqual(viewEventId('v', 'u', new Date('2026-10-26T01:00:00Z')), viewEventId('v', 'u', new Date('2026-10-27T01:00:00Z')));
});
test('menu validation and admin authz', () => {
  const ok = { label: 'Shop', icon: 'shopping-bag', order: 1, visible: true, enabled: true, contentType: 'shopping', targetId: 's' };
  assert.deepEqual(validateMenuItem(ok), []);
  assert.deepEqual(validateMenuItem({ ...ok, icon: 'evil', label: '<b>', color: 'red' }).sort(), ['color', 'icon', 'label']);
  assert.deepEqual(validateMenuItem({ ...ok, contentType: 'link', url: 'javascript:1' }), ['url']);
  assert.throws(() => requireAdmin({ admin: 'true' })); assert.throws(() => requireAdmin(null)); requireAdmin({ admin: true });
});
