import test from 'node:test';
import assert from 'node:assert/strict';
import { validateMiniAppUrl } from '../src/miniapps/url.ts';
import { openMiniApp } from '../src/miniapps/open.ts';
import * as S from '../src/miniapps/service.ts';

const hosts = ['example.com'];
const base: S.MiniAppInput = { name: 'Game', description: 'd', url: 'https://t.me/mygame_bot/play', order: 1, status: 'draft', parentId: 'games', openBehavior: 'telegram' };
const admin: S.Ctx = { userId: '1', role: 'admin' }, user: S.Ctx = { userId: '2', role: 'user' };
function mem(): S.Repo {
  const m = new Map<string, S.MiniApp>(); let n = 0;
  return {
    async insert(a) { const x = { ...a, id: String(++n) }; m.set(x.id, x); return x; },
    async patch(id, p) { const x = { ...m.get(id)!, ...p }; m.set(id, x); return x; },
    async remove(id) { m.delete(id); },
    async listByParent(p) { return [...m.values()].filter((a) => a.parentId === p); },
  };
}

test('URL validation', () => {
  for (const bad of ['javascript:alert(1)', 'data:text/html,x', 'http://t.me/mygame_bot/play', 'https://evil.com/x', 'https://u:p@example.com', 'https://t.me/mygame_bot', 'tg://resolve?domain=x', '']) assert.equal(validateMiniAppUrl(bad, { approvedHosts: hosts }).ok, false, bad);
  assert.equal(validateMiniAppUrl('https://t.me/mygame_bot?startapp=a', {}).ok, true);
  assert.equal(validateMiniAppUrl('https://app.example.com/x', { approvedHosts: hosts }).ok, true);
});
test('admin-only writes', async () => {
  const r = mem();
  await assert.rejects(S.createMiniApp(user, r, base, hosts), S.ForbiddenError);
  await assert.rejects(S.createMiniApp({ ...admin, blocked: true }, r, base, hosts), S.ForbiddenError);
  await assert.rejects(S.createMiniApp(admin, r, { ...base, url: 'javascript:1' }, hosts), S.ValidationError);
  await assert.rejects(S.createMiniApp(admin, r, { ...base, openBehavior: 'web' }, hosts), S.ValidationError);
  await assert.rejects(S.deleteMiniApp(user, r, '1'), S.ForbiddenError);
});
test('publish status and menu placement', async () => {
  const r = mem();
  const a = await S.createMiniApp(admin, r, base, hosts);
  const b = await S.createMiniApp(admin, r, { ...base, order: 0, parentId: 'tools' }, hosts);
  assert.equal((await S.listPublished(r, 'games')).length, 0);
  await S.setMiniAppStatus(admin, r, a.id, 'published'); await S.setMiniAppStatus(admin, r, b.id, 'published');
  assert.deepEqual((await S.listPublished(r, 'games')).map((x) => x.id), [a.id]);
  await S.setMiniAppStatus(admin, r, a.id, 'unpublished');
  assert.equal((await S.listPublished(r, 'games')).length, 0);
});
test('safe opening', () => {
  const calls: string[] = [];
  const w = { openTelegramLink: (u: string) => calls.push('tg:' + u), openLink: (u: string) => calls.push('web:' + u) };
  assert.equal(openMiniApp(base, w), 'opened-telegram');
  assert.equal(openMiniApp({ url: 'https://app.example.com/', openBehavior: 'web' }, w, hosts), 'opened-web');
  assert.equal(openMiniApp({ url: 'javascript:1', openBehavior: 'web' }, w, hosts), 'fallback');
  assert.equal(openMiniApp(base, undefined), 'fallback');
  assert.equal(calls.length, 2);
});
