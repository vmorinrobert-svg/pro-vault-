// Usage: GOOGLE_APPLICATION_CREDENTIALS=/path/key.json node scripts/set-admin.mjs <telegramUserId>
// Requires: npm i firebase-admin. The key file stays OUTSIDE the repo. Never commit it.
import { initializeApp, applicationDefault } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';
const tgId = process.argv[2];
if (!/^\d{1,15}$/.test(tgId ?? '')) { console.error('Provide a numeric Telegram user ID'); process.exit(1); }
initializeApp({ credential: applicationDefault() });
const uid = `tg_${tgId}`;
const auth = getAuth();
try { await auth.getUser(uid); } catch { await auth.createUser({ uid }); }
await auth.setCustomUserClaims(uid, { admin: true });
await getFirestore().doc(`users/${uid}`).set({ uid, telegramId: tgId, role: 'admin', status: 'active', updatedAt: FieldValue.serverTimestamp() }, { merge: true });
await getFirestore().collection('adminAuditLogs').add({ action: 'admin.bootstrap', actorUid: 'script', targetUid: uid, createdAt: FieldValue.serverTimestamp() });
console.log(`Admin claim set for ${uid}. The user must re-authenticate to receive it.`);
