# ProApp Vault (monorepo) — STATUS: FOUNDATION, NOT THE FINISHED PRODUCT
Implemented and unit-tested: Telegram initData verification, Firebase custom-token route (apps/main), server-side admin check,
Cloudinary signing + upload validation (apps/admin route), unlock entitlements (verified vs link_visit), view dedupe IDs,
menu and Mini App validation. Also: Firestore rules/indexes/schema and the admin bootstrap script.
NOT implemented: all UI (feed, interactions, Saved/More/Account, admin screens, Visual Builder), Firestore repositories and CRUD routes,
Adsterra banner, ad-provider callback route, analytics, moderation. Not run: npm install, tsc, next build, Firestore emulator.

## Setup
    cp .env.example apps/main/.env.local && cp .env.example apps/admin/.env.local   # fill in values
    npm install
    npm test            # shared-core tests (node:test, Node >= 22.6)
    npm run typecheck
    npm run dev:main    # http://localhost:3000       npm run dev:admin  # http://localhost:3001
## Firebase
See firebase/FIREBASE_SETUP.md. Deploy: `cd firebase && firebase deploy --only firestore:rules,firestore:indexes`.
Admin bootstrap: `GOOGLE_APPLICATION_CREDENTIALS=/secure/key.json node scripts/set-admin.mjs <telegramId>` (after `npm i firebase-admin`).
## Vercel
Two projects from this repo, Root Directory `apps/main` and `apps/admin`; set the .env.example variables in both
(admin also needs CLOUDINARY_*). Telegram: BotFather menu button / Mini App URL = the main app's HTTPS URL.

## Firebase Console setup (project: proappvault-ffe3f)
1. Authentication > Get started (no sign-in provider needed; users sign in with server-minted custom tokens).
2. Firestore Database > Create database (production mode), then deploy rules/indexes:
   `npm i -g firebase-tools && firebase login && cd firebase && firebase deploy --only firestore:rules,firestore:indexes`
3. Project settings > Service accounts > Generate new private key. Copy client_email and private_key into the Vercel env vars
   FIREBASE_ADMIN_CLIENT_EMAIL / FIREBASE_ADMIN_PRIVATE_KEY (keep \n escapes). Do NOT commit the key file.
4. Client init lives in packages/shared/src/client/firebase.ts (Analytics via dynamic import, browser-only, only if supported).
Also implemented since the first README: the admin Mini App directory API (apps/admin/app/api/miniapps).
